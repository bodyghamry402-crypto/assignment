//part 1
// 1
//let a="123"
//let b=7
//let r=a+b
//console.log(r)

// 2
//let x = 0
//if x!=0
//console.log("Invalid")


// 3
//let arr=[1,2,3,4,5,6,7,8,9,10];
//let evennumber=arr.filter(num=> num %2===0);
//console.log(evennumber);


// 4
//let x=[1,2,3,4,5]
//let y=filter
//return 
//console.log(y)  

// 5
//const x = [1 , 2 , 3 ];
//const y = [ 4 , 5 , 6 ];
//const z = x.concat(y);

// 6
//switch (new Date().getDay()) {
    //case 1:
     // day = "Sunday";
      //break;
    //case 2:
     // day = "Monday";
     // break;
   // case 3:
   //    day = "Tuesday";
   //   break;
   // case 4:
   //   day = "Wednesday";
   //   break;
   // case 5:
   //   day = "Thursday";
   //   break;
   // case 6:
   //   day = "Friday";
   //   break;
   // case 7:
   //   day = "Saturday";
//  }
//console.log((2))

// 7
//const x = ["a","ab","abc"];
//const y = x.map(function{return .length});
//console.log(y)

// 8
//function (15){
//if(n%3==0 && n%5==0){
//return "Divisible by both"
//}
//}
//console.log((15))

// 9
//let x =5
//let y =x*x
//console.log(y)

// 10
//let x = name:"John"
//let y = age:25
//let z = x+y
//return name+" is "+age+" years old"
//console.log(z)

// 11
//function summation(x,y) {
  //  console.log(x+y);
    //return(x+y)
//}
//console.log(summation(3,7));

// 12

// 13

// 14

// 15
//function z(a){
//return a.split(" ")
//}
//console.log(z("The"+ "quick"+ "brown"+ "fox"))


//part 2
1// 
//forEach
//can work just in array
//can use as  callback function
//can not use break or continue.

//for...of
//can use iterable (array, string, map, set…)
//can use break or continue. 
//2

//Hoisting is a JavaScript behavior where variable and function declarations are moved to the top of their scope before the code runs

//The Temporal Dead Zone is the period of time during which a `let` or `const` variable is **hoisted but not yet initialized**, so accessing it results in a **ReferenceError**

//console.log(x); 
//var x = 10;

//console.log(y); 
//let y = 20;
//3

//== same value
//=== same value and same datatype

//4 
 //try…catch prevents the program from stopping on errors

//Essential in async functions to safely handle network or API errors

//5

//Conversion :  manually change a value’s type  انت اللي بتحدد
//Coercion : JavaScript automatically changes types during operations جافا هي اللي بتحدد
